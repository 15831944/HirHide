#ifndef mine_h
#define mine_h

#include "base.h"

#include "dmine.h"
#include "tmine.h"
#include "wmine.h"

#endif
