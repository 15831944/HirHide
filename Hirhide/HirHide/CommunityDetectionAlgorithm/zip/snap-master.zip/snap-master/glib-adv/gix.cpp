// no code, all in templates
