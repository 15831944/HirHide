#
#	configuration variables for the example

## Main application file
MAIN = centrality
DEPH = 
DEPCPP = 

