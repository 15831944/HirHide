#
#	configuration variables for the example

## Main application file
MAIN = lshtest
DEPH = $(EXSNAPEXP)/lsh.h
DEPCPP = $(EXSNAPEXP)/lsh.cpp
CXXFLAGS += $(CXXOPENMP)

