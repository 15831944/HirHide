#
#	configuration variables for the example

## Main application file
MAIN = ncpplot
DEPH = $(EXSNAPADV)/ncp.h
DEPCPP = $(EXSNAPADV)/ncp.cpp

